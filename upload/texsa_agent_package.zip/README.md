# PRD کوتاه نسخه آنلاین تکسا

هدف: ساخت نسخه آنلاین فارسی/RTL که فایل .svzt تکسا را به صورت XML بخواند، تمام جدول‌ها را بدون حذف ذخیره کند، UI حرفه‌ای روی همان ساختار بدهد و خروجی سازگار تولید کند.

منبع حقیقت: جدول‌های mirror تکسا، نه مدل دمو قبلی.

فایل‌های همراه:
- TEXSA_REBUILD_PROMPT.md
- texsa_blank_template.svzt
- texsa_blank_template.xml
- texsa_schema_summary.json
- texsa_table_map.md

قانون طلایی: همه فیلدهای تکسا اول String/Text ذخیره شوند تا فرمت اصلی نابود نشود. نوع عدد/تاریخ فقط در لایه UI/محاسبات parse شود.
