"use client";

import { useState } from "react";
import { AppHeader } from "@/components/app-header";
import { AppSidebar } from "@/components/app-sidebar";
import { DashboardView } from "@/components/views/dashboard-view";
import { ProjectsView } from "@/components/views/projects-view";
import { ProjectDetail } from "@/components/views/project/project-detail";
import { BaseDataView } from "@/components/views/base-data-view";
import { ReportsView } from "@/components/views/reports-view";
import { UsersView } from "@/components/views/users-view";
import { SettingsView } from "@/components/views/settings-view";
import { useAppStore } from "@/lib/store";
import { ProjectWizard } from "@/components/views/project/project-wizard";

export default function Home() {
  const { view, selectedProjectId } = useAppStore();
  const [wizardOpen, setWizardOpen] = useState(false);

  const showProjectDetail = view === "project-detail" && selectedProjectId;

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <AppHeader />
      <div className="flex flex-1 overflow-hidden">
        <AppSidebar />
        <main className="flex-1 overflow-y-auto">
          {view === "dashboard" && <DashboardView />}
          {view === "projects" && <ProjectsView />}
          {showProjectDetail && <ProjectDetail />}
          {view === "base-data" && <BaseDataView />}
          {view === "reports" && <ReportsView />}
          {view === "users" && <UsersView />}
          {view === "settings" && <SettingsView />}
        </main>
      </div>
      <footer className="sticky bottom-0 z-30 mt-auto border-t bg-gradient-to-l from-card via-card to-amber-50/30 dark:to-amber-950/10 px-4 py-3">
        <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-2 text-xs text-muted-foreground">
          {/* Right side: Branding & user */}
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-bold text-foreground bg-gradient-to-l from-amber-600 to-orange-600 bg-clip-text text-transparent">
              متره‌یار
            </span>
            <span className="hidden sm:inline text-muted-foreground/40">|</span>
            <span className="hidden sm:inline">پلتفرم متره و برآورد</span>
            <span className="hidden md:inline text-muted-foreground/40">|</span>
            <span className="hidden md:inline">نسخه ۱.۲</span>
            <span className="hidden lg:inline text-muted-foreground/40">|</span>
            <span className="hidden lg:flex items-center gap-1.5">
              <span className="size-1.5 rounded-full bg-amber-500" />
              کاربر: آرش محمدی
            </span>
            <span className="hidden xl:inline text-muted-foreground/40">|</span>
            <span className="hidden xl:flex items-center gap-1.5">
              پروژه‌های فعال: ۳
            </span>
          </div>
          {/* Left side: Status, shortcuts, help */}
          <div className="flex flex-wrap items-center gap-3">
            <span className="flex items-center gap-1.5">
              <span className="size-2 rounded-full bg-emerald-500 animate-pulse" />
              اتصال برقرار
            </span>
            <span className="hidden sm:inline text-muted-foreground/40">|</span>
            <span className="hidden sm:flex items-center gap-1.5">
              <span className="rounded border px-1 py-0.5 text-[9px] font-mono">⌘K</span>
              جستجوی سریع
            </span>
            <span className="hidden md:inline text-muted-foreground/40">|</span>
            <span className="hidden md:flex items-center gap-1.5">
              <span className="rounded border px-1 py-0.5 text-[9px] font-mono">⌘N</span>
              پروژه جدید
            </span>
            <span className="text-muted-foreground/40">|</span>
            <a href="#" className="flex items-center gap-1 hover:text-amber-600 transition-colors">
              راهنما و پشتیبانی
            </a>
            <span className="text-muted-foreground/40">|</span>
            <span>© ۱۴۰۴ — شرکت مهندسین مشاور عمران پارس</span>
          </div>
        </div>
      </footer>
      <ProjectWizard open={wizardOpen} onOpenChange={setWizardOpen} />
    </div>
  );
}
