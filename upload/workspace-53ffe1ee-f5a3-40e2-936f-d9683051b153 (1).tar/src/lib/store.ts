"use client";

import { create } from "zustand";

export type ViewMode =
  | "dashboard"
  | "projects"
  | "project-detail"
  | "base-data"
  | "reports"
  | "users"
  | "settings";

export type ProjectTab =
  | "overview"
  | "contract"
  | "detail-boq"
  | "financial-sheet"
  | "chapters"
  | "payments"
  | "adjustment"
  | "reports";

interface AppState {
  // ناوبری
  view: ViewMode;
  selectedProjectId: string | null;
  selectedProjectTab: ProjectTab;
  sidebarCollapsed: boolean;
  // تنظیمات
  setView: (v: ViewMode) => void;
  selectProject: (id: string | null, tab?: ProjectTab) => void;
  setProjectTab: (t: ProjectTab) => void;
  toggleSidebar: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  view: "dashboard",
  selectedProjectId: null,
  selectedProjectTab: "overview",
  sidebarCollapsed: false,
  setView: (v) => set({ view: v, selectedProjectId: v === "project-detail" ? null : null }),
  selectProject: (id, tab = "overview") =>
    set({ selectedProjectId: id, view: "project-detail", selectedProjectTab: tab }),
  setProjectTab: (t) => set({ selectedProjectTab: t }),
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
}));
