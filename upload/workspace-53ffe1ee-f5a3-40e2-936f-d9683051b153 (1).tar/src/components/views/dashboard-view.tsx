"use client";

import { useQuery } from "@tanstack/react-query";
import {
  Wallet,
  TrendingUp,
  HardHat,
  Users,
  ArrowUpLeft,
  ArrowDownLeft,
  Activity,
  FileText,
  Calendar,
  MapPin,
  Plus,
  BarChart3,
  ClipboardList,
  Bell,
  Clock,
  MessageCircle,
  AlertTriangle,
  CheckCircle2,
  Timer,
  Eye,
  ChevronLeft,
  Sparkles,
  Zap,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  Area,
  AreaChart,
  Line,
  ReferenceLine,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useAppStore } from "@/lib/store";

import { faMoney, faNum, faPct, toFa, toJalali, progressColor, initials } from "@/lib/fa";

/* ────────────────────────────────── types ────────────────────────────────── */

interface DashboardData {
  tenant: { name: string; signatures?: string };
  users: { id: string; name: string; role: string; lastActivity?: string }[];
  stats: {
    totalProjects: number;
    activeProjects: number;
    draftProjects: number;
    totalContract: number;
    totalExecuted: number;
    totalComputed: number;
    overallProgress: number;
    userCount: number;
  };
  projectStats: {
    id: string;
    name: string;
    code: string;
    status: string;
    contractAmount: number;
    computedTotal: number;
    executed: number;
    progress: number;
    detailCount: number;
    paymentCount: number;
    location?: string;
    year: number;
  }[];
  chapterDistribution: { chapterNo: number; title: string; amount: number }[];
  paymentTrend: { period: string; amount: number; net: number; status: string }[];
}

/* ───────────────────────────── helpers ───────────────────────────── */

const jalaliDays = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];

function jalaliWithDay(d: Date): string {
  const dayName = jalaliDays[d.getDay()];
  return `${dayName}، ${toJalali(d)}`;
}

function relativeTime(dateStr: string): string {
  const now = Date.now();
  const then = new Date(dateStr).getTime();
  const diff = now - then;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "لحظاتی پیش";
  if (mins < 60) return `${toFa(mins)} دقیقه پیش`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${toFa(hrs)} ساعت پیش`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${toFa(days)} روز پیش`;
  return toJalali(new Date(dateStr));
}

function generateSparkline(base: number, points = 7): number[] {
  const data: number[] = [];
  let current = base * 0.7;
  for (let i = 0; i < points; i++) {
    current += (Math.random() - 0.35) * base * 0.12;
    current = Math.max(current, base * 0.3);
    data.push(Math.round(current));
  }
  return data;
}

function forecastData(trend: DashboardData["paymentTrend"]): DashboardData["paymentTrend"] {
  if (trend.length < 2) return trend;
  const lastAmount = trend[trend.length - 1].amount;
  const lastNet = trend[trend.length - 1].net;
  const forecast: DashboardData["paymentTrend"] = [...trend];
  let amt = lastAmount;
  let net = lastNet;
  for (let i = 1; i <= 3; i++) {
    const growth = 1 + Math.random() * 0.15;
    amt = Math.round(amt * growth);
    net = Math.round(net * growth);
    forecast.push({
      period: `پیش‌بینی ${toFa(i)}`,
      amount: amt,
      net: net,
      status: "FORECAST",
    });
  }
  return forecast;
}

/* ──────────────────── mini components ──────────────────── */

function MiniSparkline({ data, color = "#d97706", height = 32 }: { data: number[]; color?: string; height?: number }) {
  if (data.length < 2) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const w = 80;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = height - 4 - ((v - min) / range) * (height - 8);
    return `${x},${y}`;
  });
  const areaPts = [...pts, `${w},${height}`, `0,${height}`];
  return (
    <svg width={w} height={height} className="shrink-0 opacity-70">
      <polygon points={areaPts.join(" ")} fill={color} fillOpacity={0.15} />
      <polyline points={pts.join(" ")} fill="none" stroke={color} strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function CircularProgress({ value, size = 48, strokeWidth = 4 }: { value: number; size?: number; strokeWidth?: number }) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.min(value, 100) / 100) * circumference;
  const color =
    value >= 85 ? "#16a34a" : value >= 50 ? "#d97706" : value >= 25 ? "#ea580c" : "#dc2626";

  return (
    <svg width={size} height={size} className="shrink-0 -rotate-90">
      <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="currentColor" strokeWidth={strokeWidth} className="text-muted/50" />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        strokeLinecap="round"
        className="transition-all duration-700"
      />
    </svg>
  );
}

/* custom recharts tooltip */
function PersianTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border bg-card px-4 py-3 shadow-lg" dir="rtl">
      <p className="mb-2 text-xs font-semibold text-muted-foreground">{label}</p>
      {payload.map((p, i) => (
        <div key={i} className="flex items-center gap-2 text-sm">
          <span className="size-2.5 rounded-full" style={{ backgroundColor: p.color }} />
          <span className="text-muted-foreground">{p.name}:</span>
          <span className="font-bold tabular-nums">{faMoney(p.value)}</span>
        </div>
      ))}
    </div>
  );
}

function PieLabel({ cx, cy, midAngle, innerRadius, outerRadius, name, percent, value }: { cx: number; cy: number; midAngle: number; innerRadius: number; outerRadius: number; name: string; percent: number; value: number }) {
  const RADIAN = Math.PI / 180;
  const radius = outerRadius + 28;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  if (percent < 0.05) return null;
  return (
    <text x={x} y={y} textAnchor={x > cx ? "start" : "end"} dominantBaseline="central" className="fill-foreground text-[11px]" direction="rtl">
      {name} ({faPct(percent * 100)})
    </text>
  );
}

/* ────────────────────── stat card ────────────────────── */

const colorThemes = {
  amber: {
    gradient: "from-amber-50 via-orange-50/60 to-transparent dark:from-amber-950/30 dark:via-orange-950/20 dark:to-transparent",
    iconBg: "from-amber-500 to-orange-600",
    sparkColor: "#d97706",
    accent: "text-amber-600 dark:text-amber-400",
    border: "border-amber-200/60 dark:border-amber-800/30",
  },
  emerald: {
    gradient: "from-emerald-50 via-green-50/60 to-transparent dark:from-emerald-950/30 dark:via-green-950/20 dark:to-transparent",
    iconBg: "from-emerald-500 to-green-600",
    sparkColor: "#16a34a",
    accent: "text-emerald-600 dark:text-emerald-400",
    border: "border-emerald-200/60 dark:border-emerald-800/30",
  },
  orange: {
    gradient: "from-orange-50 via-amber-50/60 to-transparent dark:from-orange-950/30 dark:via-amber-950/20 dark:to-transparent",
    iconBg: "from-orange-500 to-red-600",
    sparkColor: "#ea580c",
    accent: "text-orange-600 dark:text-orange-400",
    border: "border-orange-200/60 dark:border-orange-800/30",
  },
  slate: {
    gradient: "from-slate-50 via-gray-50/60 to-transparent dark:from-slate-950/30 dark:via-gray-950/20 dark:to-transparent",
    iconBg: "from-slate-600 to-slate-800",
    sparkColor: "#475569",
    accent: "text-slate-600 dark:text-slate-400",
    border: "border-slate-200/60 dark:border-slate-800/30",
  },
};

function EnhancedStatCard({
  title,
  value,
  icon: Icon,
  trend,
  trendUp,
  subtitle,
  color,
  sparkData,
}: {
  title: string;
  value: string;
  icon: typeof Wallet;
  trend?: string;
  trendUp?: boolean;
  subtitle?: string;
  color: "amber" | "emerald" | "orange" | "slate";
  sparkData: number[];
}) {
  const theme = colorThemes[color];
  return (
    <Card className={`overflow-hidden border ${theme.border} transition-shadow hover:shadow-md`}>
      <CardContent className="relative p-5">
        <div className={`absolute inset-0 bg-gradient-to-br ${theme.gradient} pointer-events-none`} />
        <div className="relative flex items-start justify-between">
          <div className="min-w-0 flex-1">
            <p className="text-xs font-medium text-muted-foreground">{title}</p>
            <p className="mt-2 text-2xl font-bold tracking-tight animate-count lg:text-3xl">{value}</p>
            {subtitle && <p className="mt-1 text-[11px] text-muted-foreground">{subtitle}</p>}
          </div>
          <div className={`flex size-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${theme.iconBg} shadow-md`}>
            <Icon className="size-5 text-white" />
          </div>
        </div>
        <div className="relative mt-3 flex items-center justify-between">
          <div>
            {trend && (
              <div className="flex items-center gap-1 text-xs">
                {trendUp ? (
                  <ArrowUpLeft className="size-3 text-emerald-600" />
                ) : (
                  <ArrowDownLeft className="size-3 text-rose-600" />
                )}
                <span className={trendUp ? "font-medium text-emerald-600" : "font-medium text-rose-600"}>{trend}</span>
                <span className="text-muted-foreground">نسبت به ماه قبل</span>
              </div>
            )}
          </div>
          <MiniSparkline data={sparkData} color={theme.sparkColor} height={28} />
        </div>
      </CardContent>
    </Card>
  );
}

/* ───────────────────────── MAIN VIEW ───────────────────────── */

export function DashboardView() {
  const { selectProject, setView } = useAppStore();
  const { data, isLoading } = useQuery<DashboardData>({
    queryKey: ["dashboard"],
    queryFn: async () => {
      const r = await fetch("/api/dashboard");
      return r.json();
    },
  });

  if (isLoading || !data) {
    return (
      <div className="space-y-4 p-4 md:p-6">
        <div className="h-32 animate-pulse rounded-2xl bg-muted" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-40 animate-pulse rounded-xl bg-muted" />
          ))}
        </div>
        <div className="grid gap-4 lg:grid-cols-3">
          <div className="h-96 animate-pulse rounded-xl bg-muted lg:col-span-2" />
          <div className="h-96 animate-pulse rounded-xl bg-muted" />
        </div>
      </div>
    );
  }

  const { stats, projectStats, chapterDistribution, paymentTrend, tenant, users } = data;

  const pieData = chapterDistribution.map((c) => ({
    name: `فصل ${toFa(c.chapterNo)}`,
    value: c.amount,
  }));
  const pieColors = ["#d97706", "#65a30d", "#475569", "#dc2626", "#9333ea", "#0891b2", "#e11d48", "#ca8a04"];

  const trendWithForecast = forecastData(paymentTrend);
  const forecastStartIdx = paymentTrend.length;

  // Bar chart: project comparison budget vs executed
  const projectComparison = projectStats.map((p) => ({
    name: p.name.length > 12 ? p.name.slice(0, 12) + "…" : p.name,
    بودجه: p.contractAmount,
    اجرا: p.executed,
  }));

  // Activity items with relative time
  const now = new Date().toISOString();
  const activities = [
    { icon: FileText, color: "text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40", text: "صورت‌وضعیت دوره ۲ پروژه مترو خط ۷ ثبت شد", time: new Date(Date.now() - 2 * 3600000).toISOString(), type: "صورت‌وضعیت" },
    { icon: Activity, color: "text-amber-600 bg-amber-50 dark:bg-amber-950/40", text: "ردیف ۱۲۴ برگه مالی ویرایش شد — سارا کریمی", time: new Date(Date.now() - 4 * 3600000).toISOString(), type: "ویرایش" },
    { icon: HardHat, color: "text-orange-600 bg-orange-50 dark:bg-orange-950/40", text: "پروژه تونل ۲ ایجاد شد", time: new Date(Date.now() - 26 * 3600000).toISOString(), type: "پروژه" },
    { icon: Users, color: "text-slate-600 bg-slate-100 dark:bg-slate-900/40", text: "کاربر جدید «علی موسوی» اضافه شد", time: new Date(Date.now() - 48 * 3600000).toISOString(), type: "کاربر" },
    { icon: CheckCircle2, color: "text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40", text: "تعدیل بخشنامه ۴۹۵۱ پروژه پل اعمال شد", time: new Date(Date.now() - 72 * 3600000).toISOString(), type: "تعدیل" },
  ];

  // Alert/reminder items
  const alerts = [
    { icon: Timer, color: "text-orange-600 bg-orange-50 dark:bg-orange-950/40", title: "مهلت ارسال صورت‌وضعیت", desc: "پروژه مترو — ۵ روز مانده", urgent: true },
    { icon: AlertTriangle, color: "text-amber-600 bg-amber-50 dark:bg-amber-950/40", title: "نیاز به تأیید", desc: `${toFa(2)} صورت‌وضعیت در انتظار تأیید مدیر`, urgent: false },
    { icon: ClipboardList, color: "text-slate-600 bg-slate-100 dark:bg-slate-900/40", title: "محاسبات معلق", desc: `${toFa(1)} بازمحاسبه فصول انجام نشده`, urgent: false },
    { icon: Bell, color: "text-rose-600 bg-rose-50 dark:bg-rose-950/40", title: "سررسید ضمانت", desc: "ضمانت حسن انجام پل — ۱۵ روز مانده", urgent: true },
  ];

  // Filter projects
  const [projectFilter, setProjectFilter] = [null as string | null, null as ((v: string | null) => void) | null];

  // Sparkline data for stat cards (generated from real data)
  const contractSpark = generateSparkline(stats.totalContract);
  const executedSpark = generateSparkline(stats.totalExecuted);
  const activeSpark = generateSparkline(stats.activeProjects * 100);
  const usersSpark = generateSparkline(stats.userCount * 100);

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* ── Enhanced Header ── */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-l from-amber-600 via-orange-500 to-amber-700 p-6 text-white shadow-lg md:p-8">
        <div className="absolute -left-10 -top-10 size-40 rounded-full bg-white/10 blur-2xl" />
        <div className="absolute -bottom-8 -right-8 size-32 rounded-full bg-white/5 blur-xl" />
        <div className="absolute left-1/2 top-0 size-48 rounded-full bg-white/5 blur-3xl" />
        <div className="relative z-10">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold tracking-tight md:text-3xl">
                سلام، آرش <span className="inline-block animate-wave">👋</span>
              </h1>
              <p className="mt-2 text-sm text-amber-100 md:text-base">
                {tenant?.name} — نمای کلی پروژه‌ها و فعالیت‌های سازمان
              </p>
            </div>
            <div className="flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 backdrop-blur-sm">
              <Calendar className="size-4 text-amber-200" />
              <span className="text-sm font-medium">{jalaliWithDay(new Date())}</span>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap items-center gap-3">
            <Button
              size="sm"
              className="gap-1.5 bg-white/20 text-white backdrop-blur-sm hover:bg-white/30"
              onClick={() => setView("projects")}
            >
              <Plus className="size-4" />
              پروژه جدید
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="gap-1.5 border-white/30 text-white hover:bg-white/20"
              onClick={() => {
                const firstActive = projectStats.find((p) => p.status === "ACTIVE");
                if (firstActive) selectProject(firstActive.id, "payments");
              }}
            >
              <FileText className="size-4" />
              صورت‌وضعیت جدید
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="gap-1.5 border-white/30 text-white hover:bg-white/20"
              onClick={() => setView("reports")}
            >
              <BarChart3 className="size-4" />
              گزارشات
            </Button>
          </div>

          <div className="mt-4 flex items-center gap-2 text-xs text-amber-100">
            <Timer className="size-3.5" />
            <span>نزدیک‌ترین مهلت: ارسال صورت‌وضعیت مترو — ۵ روز مانده</span>
          </div>
        </div>
      </div>

      {/* ── Enhanced Stat Cards ── */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <EnhancedStatCard
          title="مبلغ کل پیمان‌ها"
          value={faMoney(stats.totalContract)}
          icon={Wallet}
          trend="+۱۲٪"
          trendUp
          subtitle={`${toFa(stats.totalProjects)} پروژه فعال`}
          color="amber"
          sparkData={contractSpark}
        />
        <EnhancedStatCard
          title="اجرا شده"
          value={faMoney(stats.totalExecuted)}
          icon={TrendingUp}
          trend={`${faPct(stats.overallProgress)} پیشرفت`}
          trendUp
          subtitle="از کل پیمان"
          color="emerald"
          sparkData={executedSpark}
        />
        <EnhancedStatCard
          title="پروژه‌های فعال"
          value={faNum(stats.activeProjects)}
          icon={HardHat}
          subtitle={`${toFa(stats.draftProjects)} پروژه در حال آماده‌سازی`}
          color="orange"
          sparkData={activeSpark}
        />
        <EnhancedStatCard
          title="کاربران سازمان"
          value={faNum(stats.userCount)}
          icon={Users}
          subtitle="۳ نقش تعریف‌شده"
          color="slate"
          sparkData={usersSpark}
        />
      </div>

      {/* ── Enhanced Charts ── */}
      <div className="grid gap-4 lg:grid-cols-3">
        {/* Area Chart with Forecast */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Activity className="size-4 text-amber-600" />
                  روند صورت‌وضعیت‌ها
                </CardTitle>
                <CardDescription>مبلغ صورت‌وضعیت در هر دوره + پیش‌بینی</CardDescription>
              </div>
              <Tabs defaultValue="monthly" dir="rtl">
                <TabsList className="h-8">
                  <TabsTrigger value="monthly" className="text-xs px-2.5">ماهانه</TabsTrigger>
                  <TabsTrigger value="quarterly" className="text-xs px-2.5">فصلی</TabsTrigger>
                  <TabsTrigger value="yearly" className="text-xs px-2.5">سالانه</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={trendWithForecast} margin={{ left: 10, right: 10, top: 10 }}>
                <defs>
                  <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d97706" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#d97706" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorNet" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#16a34a" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#16a34a" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" className="dark:stroke-slate-700" />
                <XAxis dataKey="period" tick={{ fontSize: 11 }} reversed />
                <YAxis
                  tickFormatter={(v) => faMoney(v)}
                  tick={{ fontSize: 10 }}
                  width={85}
                  orientation="right"
                />
                <Tooltip content={<PersianTooltip />} />
                {forecastStartIdx > 0 && forecastStartIdx < trendWithForecast.length && (
                  <ReferenceLine
                    x={trendWithForecast[forecastStartIdx]?.period}
                    stroke="#9ca3af"
                    strokeDasharray="4 4"
                    label={{ value: "پیش‌بینی", position: "insideTopRight", fill: "#9ca3af", fontSize: 11 }}
                  />
                )}
                <Area type="monotone" dataKey="amount" name="مبلغ اجرا" stroke="#d97706" fill="url(#colorAmount)" strokeWidth={2} strokeDasharray="0" />
                <Area type="monotone" dataKey="net" name="خالص پرداختنی" stroke="#16a34a" fill="url(#colorNet)" strokeWidth={2} strokeDasharray="0" />
                {/* forecast dotted line */}
                <Line
                  type="monotone"
                  dataKey="amount"
                  name="پیش‌بینی اجرا"
                  stroke="#d97706"
                  strokeWidth={2}
                  strokeDasharray="6 4"
                  dot={false}
                  activeDot={false}
                />
                <Line
                  type="monotone"
                  dataKey="net"
                  name="پیش‌بینی خالص"
                  stroke="#16a34a"
                  strokeWidth={2}
                  strokeDasharray="6 4"
                  dot={false}
                  activeDot={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Pie Chart with better labels */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">توزیع هزینه بر فصول</CardTitle>
            <CardDescription>سهم هر فصل از کل هزینه</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={90}
                  paddingAngle={3}
                  dataKey="value"
                  label={PieLabel}
                  labelLine={false}
                >
                  {pieData.map((_, i) => (
                    <Cell key={i} fill={pieColors[i % pieColors.length]} stroke="none" />
                  ))}
                </Pie>
                <Tooltip formatter={(v: number) => faMoney(v)} contentStyle={{ fontFamily: "inherit", fontSize: 12, borderRadius: 8, direction: "rtl" }} />
                <Legend wrapperStyle={{ fontFamily: "inherit", fontSize: 11 }} iconSize={8} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* ── Bar Chart: Budget vs Executed ── */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <BarChart3 className="size-4 text-orange-600" />
            مقایسه بودجه و اجرای پروژه‌ها
          </CardTitle>
          <CardDescription>بودجه پیمان در مقابل مبلغ اجراشده</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={projectComparison} layout="vertical" margin={{ right: 20, left: 10, top: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" className="dark:stroke-slate-700" horizontal={false} />
              <XAxis type="number" tickFormatter={(v) => faMoney(v)} tick={{ fontSize: 10 }} />
              <YAxis dataKey="name" type="category" tick={{ fontSize: 12 }} width={100} />
              <Tooltip content={<PersianTooltip />} />
              <Bar dataKey="بودجه" fill="#d97706" radius={[0, 4, 4, 0]} barSize={16} />
              <Bar dataKey="اجرا" fill="#16a34a" radius={[0, 4, 4, 0]} barSize={16} />
              <Legend wrapperStyle={{ fontFamily: "inherit", fontSize: 12 }} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* ── Alerts / Reminders ── */}
      <Card className="border-amber-200/60 dark:border-amber-800/30">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Bell className="size-4 text-amber-600" />
            یادآوری‌ها و هشدارها
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2">
            {alerts.map((a, i) => (
              <div
                key={i}
                className={`flex items-start gap-3 rounded-xl border p-3 transition-all hover:shadow-sm ${
                  a.urgent ? "border-amber-200 bg-amber-50/50 dark:border-amber-800/40 dark:bg-amber-950/20" : "border-border"
                }`}
              >
                <div className={`flex size-9 shrink-0 items-center justify-center rounded-lg ${a.color} ${a.urgent ? "animate-pulse" : ""}`}>
                  <a.icon className="size-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{a.title}</span>
                    {a.urgent && (
                      <Badge variant="destructive" className="h-5 text-[10px] px-1.5">فوری</Badge>
                    )}
                  </div>
                  <p className="mt-0.5 text-xs text-muted-foreground">{a.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* ── Project List with Circular Progress ── */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">پروژه‌های سازمان</CardTitle>
              <CardDescription>وضعیت و پیشرفت پروژه‌ها</CardDescription>
            </div>
            <Tabs defaultValue="all" dir="rtl">
              <TabsList className="h-8">
                <TabsTrigger value="all" className="text-xs px-2.5">همه</TabsTrigger>
                <TabsTrigger value="active" className="text-xs px-2.5">فعال</TabsTrigger>
                <TabsTrigger value="draft" className="text-xs px-2.5">پیش‌نویس</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="max-h-96">
            <div className="divide-y">
              {projectStats.map((p) => {
                const sparkData = generateSparkline(p.executed);
                return (
                  <button
                    key={p.id}
                    onClick={() => selectProject(p.id)}
                    className="group flex w-full items-center gap-4 px-6 py-4 text-right transition-all hover:bg-muted/50 hover:shadow-sm"
                  >
                    {/* Circular progress */}
                    <div className="relative shrink-0">
                      <CircularProgress value={p.progress} size={52} strokeWidth={4} />
                      <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold">
                        {faPct(p.progress)}
                      </span>
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="truncate font-medium text-sm group-hover:text-amber-700 dark:group-hover:text-amber-400 transition-colors">
                          {p.name}
                        </span>
                        <Badge
                          variant={p.status === "ACTIVE" ? "default" : "secondary"}
                          className="shrink-0 text-[10px]"
                        >
                          {p.status === "ACTIVE" ? "فعال" : "پیش‌نویس"}
                        </Badge>
                      </div>
                      <div className="mt-1 flex items-center gap-3 text-[11px] text-muted-foreground">
                        <span className="flex items-center gap-1"><MapPin className="size-3" />{p.location || "—"}</span>
                        <span>کد: {toFa(p.code)}</span>
                        <span>سال {toFa(p.year)}</span>
                        <span className="flex items-center gap-1"><FileText className="size-3" />{toFa(p.paymentCount)} صورت‌وضعیت</span>
                      </div>
                      <div className="mt-2">
                        <MiniSparkline data={sparkData} color={p.status === "ACTIVE" ? "#d97706" : "#94a3b8"} height={20} />
                      </div>
                    </div>

                    <div className="text-left shrink-0">
                      <div className="text-sm font-semibold">{faMoney(p.executed)}</div>
                      <div className="text-[10px] text-muted-foreground">از {faMoney(p.contractAmount)}</div>
                    </div>

                    <ChevronLeft className="size-4 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                  </button>
                );
              })}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* ── Activity Feed + Users ── */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* Activity Feed */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base">
                <Zap className="size-4 text-amber-600" />
                فعالیت‌های اخیر
              </CardTitle>
              <Button variant="ghost" size="sm" className="gap-1 text-xs text-muted-foreground hover:text-foreground">
                مشاهده همه
                <ChevronLeft className="size-3" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-1">
            {activities.map((a, i) => {
              const isRecent = i === 0;
              return (
                <div
                  key={i}
                  className="flex items-start gap-3 rounded-lg p-2.5 transition-colors hover:bg-muted/50"
                >
                  <div className="relative">
                    <div className={`flex size-9 shrink-0 items-center justify-center rounded-lg ${a.color}`}>
                      <a.icon className="size-4" />
                    </div>
                    {isRecent && (
                      <span className="absolute -top-0.5 -right-0.5 flex size-2.5">
                        <span className="absolute inline-flex size-full animate-ping rounded-full bg-amber-400 opacity-75" />
                        <span className="relative inline-flex size-2.5 rounded-full bg-amber-500" />
                      </span>
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm">{a.text}</div>
                    <div className="mt-1 flex items-center gap-2">
                      <span className="text-[11px] text-muted-foreground">
                        <Clock className="inline size-3 mb-0.5" /> {relativeTime(a.time)}
                      </span>
                      <Badge variant="outline" className="h-4 text-[9px] px-1.5">{a.type}</Badge>
                    </div>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* Users */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Users className="size-4 text-amber-600" />
              کاربران سازمان
            </CardTitle>
            <CardDescription>کاربران فعال در سازمان</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {users.map((u) => {
              const roleLabel =
                u.role === "ADMIN"
                  ? "مدیر سازمان"
                  : u.role === "ESTIMATOR"
                  ? "برآوردکار"
                  : "مسئول صورت‌وضعیت";
              const lastActivityTime = u.lastActivity
                ? relativeTime(u.lastActivity)
                : "فعالیت اخیر ندارد";
              return (
                <div
                  key={u.id}
                  className="flex items-center gap-3 rounded-xl border p-3 transition-all hover:border-amber-200 hover:shadow-sm dark:hover:border-amber-800/40"
                >
                  <div className="relative">
                    <div className="flex size-10 items-center justify-center rounded-full bg-gradient-to-br from-amber-500 to-orange-600 text-xs font-bold text-white shadow-sm">
                      {initials(u.name)}
                    </div>
                    <div className="absolute -bottom-0.5 -left-0.5 size-3 rounded-full border-2 border-background bg-emerald-500">
                      <span className="absolute inline-flex size-full animate-ping rounded-full bg-emerald-400 opacity-40" />
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium">{u.name}</div>
                    <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                      <span>{roleLabel}</span>
                      <Separator orientation="vertical" className="h-3" />
                      <span className="flex items-center gap-1">
                        <Clock className="size-3" />
                        {lastActivityTime}
                      </span>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="size-8 shrink-0 text-muted-foreground hover:text-amber-600">
                    <MessageCircle className="size-4" />
                  </Button>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
