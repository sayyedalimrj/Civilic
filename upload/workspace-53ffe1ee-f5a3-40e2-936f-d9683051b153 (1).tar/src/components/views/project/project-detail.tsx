"use client";

import { useQuery } from "@tanstack/react-query";
import {
  LayoutDashboard,
  FileText,
  ListTree,
  Sheet,
  BookOpen,
  Receipt,
  TrendingUp,
  FileBarChart,
  Star,
} from "lucide-react";
import { useAppStore, type ProjectTab } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { OverviewView } from "./overview-view";
import { ContractView } from "./contract-view";
import { DetailBoqView } from "./detail-boq-view";
import { SummaryBoqView } from "./summary-boq-view";
import { FinancialSheetView } from "./financial-sheet-view";
import { ChaptersView } from "./chapters-view";
import { PaymentsView } from "./payments-view";
import { AdjustmentView } from "./adjustment-view";
import { ReportsView } from "./reports-view";
import { toFa } from "@/lib/fa";

const TABS: { id: ProjectTab; label: string; icon: typeof FileText; step?: number }[] = [
  { id: "overview", label: "نمای کلی", icon: LayoutDashboard },
  { id: "contract", label: "پیمان و ضرایب", icon: FileText, step: 1 },
  { id: "detail-boq", label: "ریزمتره", icon: ListTree, step: 2 },
  { id: "financial-sheet", label: "برگه مالی", icon: Sheet, step: 3 },
  { id: "chapters", label: "فصول", icon: BookOpen, step: 4 },
  { id: "payments", label: "صورت‌وضعیت", icon: Receipt, step: 5 },
  { id: "adjustment", label: "تعدیل", icon: TrendingUp, step: 6 },
  { id: "reports", label: "گزارشات", icon: FileBarChart, step: 7 },
];

export function ProjectDetail() {
  const { selectedProjectId, selectedProjectTab, setProjectTab } = useAppStore();

  const { data } = useQuery<{ project: any }>({
    queryKey: ["project", selectedProjectId],
    queryFn: async () => {
      const r = await fetch(`/api/projects/${selectedProjectId}`);
      return r.json();
    },
    enabled: !!selectedProjectId,
  });

  const project = data?.project;
  const starredCount = project?.financialSheet?.filter((f: any) => f.isStarred).length || 0;

  return (
    <div className="flex h-full flex-col">
      {/* نوار تب‌ها */}
      <div className="sticky top-0 z-30 border-b bg-card/95 backdrop-blur">
        <div className="flex items-center gap-1 overflow-x-auto px-3 py-2">
          {TABS.map((tab) => {
            const active = selectedProjectTab === tab.id;
            return (
              <Button
                key={tab.id}
                variant={active ? "default" : "ghost"}
                size="sm"
                onClick={() => setProjectTab(tab.id)}
                className={cn(
                  "h-9 shrink-0 gap-1.5 text-xs",
                  active && "bg-amber-600 text-primary-foreground hover:bg-amber-700"
                )}
              >
                {tab.step && (
                  <span
                    className={cn(
                      "flex size-5 items-center justify-center rounded-full text-[10px] font-bold",
                      active ? "bg-white/20" : "bg-muted"
                    )}
                  >
                    {toFa(tab.step)}
                  </span>
                )}
                <tab.icon className="size-3.5" />
                {tab.label}
                {tab.id === "financial-sheet" && starredCount > 0 && (
                  <Badge variant="secondary" className="ml-1 gap-0.5 text-[9px]">
                    <Star className="size-2.5 fill-current" />
                    {toFa(starredCount)}
                  </Badge>
                )}
              </Button>
            );
          })}
        </div>
      </div>

      {/* محتوای تب */}
      <div className="flex-1 overflow-y-auto">
        {selectedProjectTab === "overview" && <OverviewView />}
        {selectedProjectTab === "contract" && <ContractView />}
        {selectedProjectTab === "detail-boq" && <DetailBoqView />}
        {selectedProjectTab === "financial-sheet" && <FinancialSheetView />}
        {selectedProjectTab === "chapters" && <ChaptersView />}
        {selectedProjectTab === "payments" && <PaymentsView />}
        {selectedProjectTab === "adjustment" && <AdjustmentView />}
        {selectedProjectTab === "reports" && <ReportsView />}
      </div>
    </div>
  );
}
