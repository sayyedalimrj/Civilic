"use client";

import { useState, useMemo } from "react";
import {
  FolderTree,
  Folder,
  FolderOpen,
  Database,
  FileBarChart,
  Users,
  Settings,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Plus,
  Search,
  HardHat,
  Building2,
  Ruler,
  Mountain,
  Construction,
  TrendingUp,
  Sliders,
  Star,
  LayoutDashboard,
  Eye,
  Pencil,
  Receipt,
  Activity,
  PanelRightOpen,
  ListTree,
  Sheet,
  BookOpen,
} from "lucide-react";
import { useAppStore, type ViewMode } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toFa, faMoney, initials, progressColor } from "@/lib/fa";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useQuery } from "@tanstack/react-query";

// ─── Types ─────────────────────────────────────────────────

interface ProjectItem {
  id: string;
  name: string;
  code: string;
  status: string;
  contractAmount: number;
  cachedTotal: number;
  cachedExecuted: number;
  location?: string | null;
  year: number;
  _count?: {
    detailBoqs: number;
    financialSheet: number;
    payments: number;
  };
}

// ─── Project Icon Map ──────────────────────────────────────

const projectIcons: Record<string, typeof HardHat> = {
  مترو: HardHat,
  پل: Construction,
  تونل: Mountain,
};

const projectIconColors: Record<string, string> = {
  مترو: "from-amber-500 to-amber-700",
  پل: "from-orange-500 to-orange-700",
  تونل: "from-slate-500 to-slate-700",
};

const defaultIconColor = "from-amber-600 to-orange-700";

function getProjectIcon(name: string) {
  for (const key in projectIcons) {
    if (name.includes(key)) return projectIcons[key];
  }
  return Building2;
}

function getProjectIconColor(name: string) {
  for (const key in projectIconColors) {
    if (name.includes(key)) return projectIconColors[key];
  }
  return defaultIconColor;
}

// ─── Base Data Sub-Items ───────────────────────────────────

interface BaseDataSubItem {
  icon: typeof Database;
  label: string;
  count: string;
  tab: string;
}

const BASE_DATA_ITEMS: BaseDataSubItem[] = [
  {
    icon: FolderOpen,
    label: "فهرست‌های بها",
    count: "۴ فهرست",
    tab: "price-lists",
  },
  {
    icon: TrendingUp,
    label: "شاخص‌ها",
    count: "۱۳ شاخص",
    tab: "indices",
  },
  {
    icon: Sliders,
    label: "ضرایب منطقه‌ای",
    count: "۶ ضریب",
    tab: "coefficients",
  },
  {
    icon: Mountain,
    label: "نرخ مصالح",
    count: "۱۰ نرخ",
    tab: "materials",
  },
  {
    icon: Ruler,
    label: "دیتابیس مسافت",
    count: "۳۰ رکورد",
    tab: "distances",
  },
];

// ─── Sidebar Item Component ────────────────────────────────

function SidebarItem({
  icon: Icon,
  label,
  active,
  onClick,
  badge,
}: {
  icon: typeof FolderTree;
  label: string;
  active: boolean;
  onClick: () => void;
  badge?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-all",
        active
          ? "bg-amber-100 text-amber-900 dark:bg-amber-900/40 dark:text-amber-200"
          : "text-sidebar-foreground hover:bg-sidebar-accent/70"
      )}
    >
      <Icon
        className={cn(
          "size-4 shrink-0",
          active ? "text-amber-600" : "text-muted-foreground"
        )}
      />
      <span className="flex-1 text-right">{label}</span>
      {badge && (
        <Badge
          variant="secondary"
          className="text-[10px] px-1.5 py-0"
        >
          {badge}
        </Badge>
      )}
    </button>
  );
}

// ─── Sub Item Component ────────────────────────────────────

function SubItem({
  icon: Icon,
  label,
  count,
  active,
  onClick,
}: {
  icon: typeof Database;
  label: string;
  count?: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-xs transition-colors",
        active
          ? "bg-amber-100 text-amber-900 dark:bg-amber-900/40 dark:text-amber-200"
          : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
      )}
    >
      <Icon
        className={cn(
          "size-3.5 shrink-0",
          active ? "text-amber-600" : "text-muted-foreground"
        )}
      />
      <span className="flex-1 text-right">{label}</span>
      {count && (
        <span className="text-[10px] text-muted-foreground/70">{count}</span>
      )}
    </button>
  );
}

// ─── Collapsed Tooltip Button ──────────────────────────────

function CollapsedButton({
  icon: Icon,
  label,
  active,
  onClick,
  notification,
}: {
  icon: typeof FolderTree;
  label: string;
  active: boolean;
  onClick: () => void;
  notification?: number;
}) {
  return (
    <TooltipProvider delayDuration={0}>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant={active ? "default" : "ghost"}
            size="icon"
            onClick={onClick}
            className={cn(
              "relative size-10",
              active &&
                "bg-amber-600 text-primary-foreground hover:bg-amber-700"
            )}
          >
            <Icon className="size-4" />
            {notification && notification > 0 && (
              <span className="absolute -top-0.5 -left-0.5 flex size-4 items-center justify-center rounded-full bg-destructive text-[9px] text-destructive-foreground">
                {toFa(notification)}
              </span>
            )}
          </Button>
        </TooltipTrigger>
        <TooltipContent side="left" className="font-sans text-xs">
          {label}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// ─── Main Component ────────────────────────────────────────

export function AppSidebar() {
  const {
    view,
    setView,
    selectProject,
    selectedProjectId,
    sidebarCollapsed,
    toggleSidebar,
  } = useAppStore();
  const [search, setSearch] = useState("");
  const [projectsExpanded, setProjectsExpanded] = useState(true);
  const [baseDataExpanded, setBaseDataExpanded] = useState(false);
  const [hoveredProjectId, setHoveredProjectId] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);

  const { data } = useQuery<{ projects: ProjectItem[] }>({
    queryKey: ["projects"],
    queryFn: async () => {
      const r = await fetch("/api/projects");
      return r.json();
    },
  });

  const { data: dashboardData } = useQuery<{
    stats: {
      totalProjects: number;
      activeProjects: number;
      draftProjects: number;
      overallProgress: number;
    };
  }>({
    queryKey: ["dashboard"],
    queryFn: async () => {
      const r = await fetch("/api/dashboard");
      return r.json();
    },
  });

  const projects = data?.projects || [];
  const stats = dashboardData?.stats;

  const filtered = useMemo(
    () =>
      projects.filter(
        (p) =>
          p.name.includes(search) ||
          p.code.includes(search) ||
          (p.location || "").includes(search)
      ),
    [projects, search]
  );

  // Favorites / recent projects
  const favoriteProjects = useMemo(
    () =>
      favorites.length > 0
        ? projects.filter((p) => favorites.includes(p.id))
        : projects.slice(0, 2),
    [projects, favorites]
  );

  const toggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  };

  // Compute unread notifications (mock)
  const unreadNotifs = 3;
  const pendingPayments = projects.reduce(
    (sum, p) => sum + (p._count?.payments || 0),
    0
  );

  // ─── Collapsed State ─────────────────────────────────
  if (sidebarCollapsed) {
    return (
      <aside className="flex w-16 shrink-0 flex-col items-center gap-1.5 border-l bg-gradient-to-b from-sidebar via-sidebar to-sidebar/80 py-3">
        <CollapsedButton
          icon={LayoutDashboard}
          label="داشبورد"
          active={view === "dashboard"}
          onClick={() => setView("dashboard")}
        />

        <CollapsedButton
          icon={FolderTree}
          label="پروژه‌ها"
          active={view === "projects" || view === "project-detail"}
          onClick={() => setView("projects")}
        />

        {/* Project initials when project selected */}
        {selectedProjectId && (
          <TooltipProvider delayDuration={0}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-10 rounded-lg bg-amber-100 text-xs font-bold text-amber-800 dark:bg-amber-900/40 dark:text-amber-200"
                  onClick={() => selectProject(selectedProjectId)}
                >
                  {(() => {
                    const p = projects.find(
                      (pr) => pr.id === selectedProjectId
                    );
                    return p ? initials(p.name) : "پ";
                  })()}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left" className="font-sans text-xs">
                {projects.find((pr) => pr.id === selectedProjectId)?.name ||
                  "پروژه"}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}

        <CollapsedButton
          icon={Database}
          label="داده‌های پایه"
          active={view === "base-data"}
          onClick={() => setView("base-data")}
        />
        <CollapsedButton
          icon={FileBarChart}
          label="گزارشات"
          active={view === "reports"}
          onClick={() => setView("reports")}
        />
        <CollapsedButton
          icon={Users}
          label="کاربران"
          active={view === "users"}
          onClick={() => setView("users")}
          notification={0}
        />
        <CollapsedButton
          icon={Settings}
          label="تنظیمات"
          active={view === "settings"}
          onClick={() => setView("settings")}
        />

        {/* Expand button at bottom */}
        <div className="mt-auto">
          <TooltipProvider delayDuration={0}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={toggleSidebar}
                  className="size-10"
                >
                  <PanelRightOpen className="size-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left" className="font-sans text-xs">
                باز کردن نوار کناری
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </aside>
    );
  }

  // ─── Expanded State ──────────────────────────────────
  return (
    <aside className="flex w-72 shrink-0 flex-col border-l bg-gradient-to-b from-sidebar via-sidebar to-slate-50/50 dark:to-slate-900/20">
      {/* Search */}
      <div className="border-b p-3">
        <div className="relative">
          <Search className="absolute right-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="جستجوی پروژه..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 pr-8 text-sm"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <ChevronLeft className="size-3.5" />
            </button>
          )}
        </div>
        <Button
          variant="outline"
          size="sm"
          className="mt-2 w-full justify-start gap-2 text-xs border-amber-200 text-amber-700 hover:bg-amber-50 dark:border-amber-800 dark:text-amber-400 dark:hover:bg-amber-950/30"
          onClick={() => setView("projects")}
        >
          <Plus className="size-3.5" />
          پروژه جدید
        </Button>
      </div>

      <ScrollArea className="flex-1">
        <nav className="space-y-1 p-2">
          {/* Dashboard */}
          <SidebarItem
            icon={LayoutDashboard}
            label="داشبورد"
            active={view === "dashboard"}
            onClick={() => setView("dashboard")}
          />

          <div className="my-2 border-t" />

          {/* Favorites / Recent Projects */}
          {favoriteProjects.length > 0 && (
            <div className="mb-1">
              <div className="flex items-center gap-2 px-2 py-1.5">
                <Star className="size-3.5 text-amber-500" />
                <span className="text-[11px] font-medium text-muted-foreground">
                  {favorites.length > 0 ? "پروژه‌های منتخب" : "اخیراً بازدیدشده"}
                </span>
              </div>
              <div className="mr-2 space-y-0.5 border-r border-amber-200/50 dark:border-amber-800/30 pr-2">
                {favoriteProjects.map((p) => {
                  const isActive = selectedProjectId === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => selectProject(p.id)}
                      className={cn(
                        "flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-right text-xs transition-colors",
                        isActive
                          ? "bg-amber-100 text-amber-900 dark:bg-amber-900/40 dark:text-amber-200"
                          : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                      )}
                    >
                      <Star
                        className="size-3 text-amber-500 fill-amber-500 shrink-0"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavorite(p.id);
                        }}
                      />
                      <span className="truncate font-medium">{p.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Projects Section */}
          <div>
            <button
              onClick={() => setProjectsExpanded((v) => !v)}
              className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-sm font-medium text-sidebar-foreground hover:bg-sidebar-accent/70 transition-colors"
            >
              {projectsExpanded ? (
                <ChevronDown className="size-4 text-muted-foreground" />
              ) : (
                <ChevronLeft className="size-4 text-muted-foreground" />
              )}
              <Folder className="size-4 text-amber-600" />
              پروژه‌ها
              <Badge
                variant="secondary"
                className="mr-auto text-[10px] px-1.5"
              >
                {toFa(projects.length)}
              </Badge>
            </button>

            {projectsExpanded && (
              <div className="mr-3 mt-1 space-y-1 border-r border-amber-200/40 dark:border-amber-800/20 pr-2">
                {filtered.length === 0 && (
                  <div className="px-2 py-2 text-xs text-muted-foreground text-center">
                    پروژه‌ای یافت نشد
                  </div>
                )}
                {filtered.map((p) => {
                  const Icon = getProjectIcon(p.name);
                  const iconColor = getProjectIconColor(p.name);
                  const isActive = selectedProjectId === p.id;
                  const isHovered = hoveredProjectId === p.id;
                  const progress =
                    p.cachedTotal > 0
                      ? Math.round(
                          (p.cachedExecuted / p.cachedTotal) * 100
                        )
                      : 0;
                  const isFavorite = favorites.includes(p.id);

                  return (
                    <div
                      key={p.id}
                      onMouseEnter={() => setHoveredProjectId(p.id)}
                      onMouseLeave={() => setHoveredProjectId(null)}
                      className={cn(
                        "group relative rounded-lg px-2 py-2 transition-all",
                        isActive
                          ? "bg-amber-100 dark:bg-amber-900/40 shadow-sm ring-1 ring-amber-200/60 dark:ring-amber-800/40"
                          : "hover:bg-sidebar-accent/50"
                      )}
                    >
                      <div className="flex items-start gap-2">
                        {/* Project icon with colored bg */}
                        <div
                          className={cn(
                            "flex size-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br text-white shadow-sm",
                            iconColor
                          )}
                        >
                          <Icon className="size-4" />
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span
                              className={cn(
                                "truncate text-xs font-medium",
                                isActive
                                  ? "text-amber-900 dark:text-amber-200"
                                  : "text-foreground"
                              )}
                            >
                              {p.name}
                            </span>
                            {/* Status indicator */}
                            <span
                              className={cn(
                                "size-2 shrink-0 rounded-full",
                                p.status === "ACTIVE"
                                  ? "bg-emerald-500"
                                  : p.status === "DRAFT"
                                  ? "bg-amber-400"
                                  : "bg-slate-400"
                              )}
                              title={
                                p.status === "ACTIVE"
                                  ? "فعال"
                                  : p.status === "DRAFT"
                                  ? "پیش‌نویس"
                                  : "بسته‌شده"
                              }
                            />
                          </div>

                          {/* Code + Location */}
                          <div className="mt-0.5 flex items-center gap-1.5 text-[10px] text-muted-foreground">
                            <span className="font-mono">{toFa(p.code)}</span>
                            {p.location && (
                              <>
                                <span>•</span>
                                <span className="truncate">{p.location}</span>
                              </>
                            )}
                          </div>

                          {/* Contract amount (brief) */}
                          <div className="mt-1 text-[10px] text-muted-foreground">
                            مبلغ پیمان:{" "}
                            <span className="font-medium text-foreground/70">
                              {faMoney(p.contractAmount)}
                            </span>
                          </div>

                          {/* Mini progress bar */}
                          <div className="mt-1.5 flex items-center gap-2">
                            <div className="h-1 flex-1 overflow-hidden rounded-full bg-muted">
                              <div
                                className={cn(
                                  "h-full rounded-full transition-all",
                                  progressColor(progress)
                                )}
                                style={{
                                  width: `${Math.min(progress, 100)}%`,
                                }}
                              />
                            </div>
                            <span className="text-[10px] tabular-nums text-muted-foreground">
                              {toFa(progress)}٪
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Hover quick actions */}
                      <div
                        className={cn(
                          "absolute -top-1 left-1 flex items-center gap-0.5 transition-opacity",
                          isHovered
                            ? "opacity-100"
                            : "pointer-events-none opacity-0"
                        )}
                      >
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-6"
                          onClick={(e) => {
                            e.stopPropagation();
                            selectProject(p.id);
                          }}
                          title="مشاهده"
                        >
                          <Eye className="size-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-6"
                          onClick={(e) => {
                            e.stopPropagation();
                            selectProject(p.id, "detail-boq");
                          }}
                          title="ویرایش ریزمتره"
                        >
                          <Pencil className="size-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-6"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavorite(p.id);
                          }}
                          title={
                            isFavorite
                              ? "حذف از منتخب"
                              : "افزودن به منتخب"
                          }
                        >
                          <Star
                            className={cn(
                              "size-3",
                              isFavorite
                                ? "fill-amber-500 text-amber-500"
                                : "text-muted-foreground"
                            )}
                          />
                        </Button>
                      </div>

                      {/* Click area for whole item */}
                      <button
                        onClick={() => selectProject(p.id)}
                        className="absolute inset-0 z-0 cursor-pointer rounded-lg"
                        aria-label={`باز کردن پروژه ${p.name}`}
                      />
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="my-2 border-t" />

          {/* Base Data Section */}
          <div>
            <button
              onClick={() => setBaseDataExpanded((v) => !v)}
              className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-sm font-medium text-sidebar-foreground hover:bg-sidebar-accent/70 transition-colors"
            >
              {baseDataExpanded ? (
                <ChevronDown className="size-4 text-muted-foreground" />
              ) : (
                <ChevronLeft className="size-4 text-muted-foreground" />
              )}
              <Database className="size-4 text-emerald-600" />
              داده‌های پایه
            </button>
            {baseDataExpanded && (
              <div className="mr-3 mt-0.5 space-y-0.5 border-r border-emerald-200/40 dark:border-emerald-800/20 pr-2">
                {BASE_DATA_ITEMS.map((item) => (
                  <SubItem
                    key={item.tab}
                    icon={item.icon}
                    label={item.label}
                    count={item.count}
                    onClick={() => setView("base-data")}
                    active={view === "base-data"}
                  />
                ))}
              </div>
            )}
          </div>

          <div className="my-2 border-t" />

          {/* Other Navigation */}
          <SidebarItem
            icon={FileBarChart}
            label="گزارشات و خروجی"
            active={view === "reports"}
            onClick={() => setView("reports")}
          />
          <SidebarItem
            icon={Users}
            label="کاربران و نقش‌ها"
            active={view === "users"}
            onClick={() => setView("users")}
          />
          <SidebarItem
            icon={Settings}
            label="تنظیمات سازمان"
            active={view === "settings"}
            onClick={() => setView("settings")}
          />
        </nav>
      </ScrollArea>

      {/* Quick Stats Panel */}
      <div className="border-t p-3">
        <div className="rounded-xl bg-gradient-to-br from-amber-50 to-orange-50 p-3 dark:from-amber-950/30 dark:to-orange-950/20 ring-1 ring-amber-200/50 dark:ring-amber-800/30">
          {/* Stats grid */}
          <div className="grid grid-cols-3 gap-2">
            <div className="text-center">
              <div className="text-lg font-bold text-amber-700 dark:text-amber-400">
                {toFa(stats?.activeProjects || 0)}
              </div>
              <div className="text-[10px] text-muted-foreground">
                پروژه فعال
              </div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-orange-600 dark:text-orange-400">
                {toFa(pendingPayments)}
              </div>
              <div className="text-[10px] text-muted-foreground">
                صورت‌وضعیت
              </div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                {toFa(unreadNotifs)}
              </div>
              <div className="text-[10px] text-muted-foreground">
                اعلان جدید
              </div>
            </div>
          </div>

          <Separator className="my-2.5 bg-amber-200/50 dark:bg-amber-800/30" />

          {/* Connection + Version */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex size-2 rounded-full bg-emerald-500" />
              </span>
              <span className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400">
                اتصال برقرار
              </span>
            </div>
            <Badge
              variant="outline"
              className="text-[10px] border-amber-300 dark:border-amber-700"
            >
              نسخه ۱.۲
            </Badge>
          </div>
        </div>

        {/* Collapse button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleSidebar}
          className="mt-2 w-full gap-2 text-xs text-muted-foreground hover:text-foreground"
        >
          <PanelRightOpen className="size-3.5" />
          جمع کردن نوار کناری
        </Button>
      </div>
    </aside>
  );
}
