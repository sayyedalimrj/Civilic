"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Building2,
  Bell,
  Settings,
  Moon,
  Sun,
  ChevronLeft,
  Search,
  LayoutDashboard,
  FolderTree,
  Database,
  FileBarChart,
  Users,
  Receipt,
  CheckCircle2,
  AlertCircle,
  Edit3,
  ArrowLeftRight,
  Eye,
  X,
} from "lucide-react";
import { useTheme } from "next-themes";
import { useAppStore, type ViewMode, type ProjectTab } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { initials, toFa } from "@/lib/fa";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

// ─── Data Types ────────────────────────────────────────────

interface ProjectItem {
  id: string;
  name: string;
  code: string;
  status: string;
  contractAmount: number;
  cachedTotal: number;
  cachedExecuted: number;
  location?: string | null;
  year: number;
}

interface NotificationItem {
  id: string;
  type: "payment" | "boq" | "project";
  title: string;
  description: string;
  timestamp: string;
  read: boolean;
  projectId?: string;
}

// ─── Mock Notifications ────────────────────────────────────

const MOCK_NOTIFICATIONS: NotificationItem[] = [
  {
    id: "1",
    type: "payment",
    title: "تأیید صورت‌وضعیت",
    description: "صورت‌وضعیت دوره ۲ پروژه متروی تهران تأیید شد",
    timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
    read: false,
    projectId: "p1",
  },
  {
    id: "2",
    type: "boq",
    title: "ویرایش ریزمتره",
    description: "آرش محمدی ریزمتره پروژه پل صدر را ویرایش کرد",
    timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
    read: false,
    projectId: "p2",
  },
  {
    id: "3",
    type: "project",
    title: "تغییر وضعیت پروژه",
    description: "پروژه تونل توحید از پیش‌نویس به فعال تغییر یافت",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(),
    read: true,
    projectId: "p3",
  },
  {
    id: "4",
    type: "payment",
    title: "ثبت صورت‌وضعیت جدید",
    description: "صورت‌وضعیت دوره ۳ پروژه متروی تهران ایجاد شد",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 8).toISOString(),
    read: true,
    projectId: "p1",
  },
  {
    id: "5",
    type: "boq",
    title: "بروزرسانی برگه مالی",
    description: "برگه مالی پروژه پل صدر بازمحاسبه شد",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    read: true,
    projectId: "p2",
  },
];

// ─── View/Tab Label Maps ──────────────────────────────────

const VIEW_LABELS: Record<ViewMode, string> = {
  dashboard: "داشبورد",
  projects: "پروژه‌ها",
  "project-detail": "جزئیات پروژه",
  "base-data": "داده‌های پایه",
  reports: "گزارشات",
  users: "کاربران",
  settings: "تنظیمات",
};

const TAB_LABELS: Record<ProjectTab, string> = {
  overview: "نمای کلی",
  contract: "پیمان و ضرایب",
  "detail-boq": "ریزمتره",
  "financial-sheet": "برگه مالی",
  chapters: "فصول",
  payments: "صورت‌وضعیت",
  adjustment: "تعدیل",
  reports: "گزارشات",
};

// ─── Helper: Relative Time ─────────────────────────────────

function relativeTime(date: string): string {
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "همین الان";
  if (mins < 60) return `${toFa(mins)} دقیقه پیش`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${toFa(hrs)} ساعت پیش`;
  const days = Math.floor(hrs / 24);
  return `${toFa(days)} روز پیش`;
}

// ─── Notification Icon by Type ─────────────────────────────

function NotificationIcon({ type }: { type: NotificationItem["type"] }) {
  switch (type) {
    case "payment":
      return <Receipt className="size-4 text-emerald-600" />;
    case "boq":
      return <Edit3 className="size-4 text-amber-600" />;
    case "project":
      return <ArrowLeftRight className="size-4 text-orange-600" />;
  }
}

// ─── Component ─────────────────────────────────────────────

export function AppHeader() {
  const { theme, setTheme } = useTheme();
  const {
    toggleSidebar,
    sidebarCollapsed,
    view,
    selectedProjectId,
    selectedProjectTab,
    setView,
    selectProject,
  } = useAppStore();

  // Command palette state
  const [cmdOpen, setCmdOpen] = useState(false);

  // Notifications state
  const [notifications, setNotifications] = useState(MOCK_NOTIFICATIONS);
  const [notifOpen, setNotifOpen] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;

  // Fetch projects for command palette search
  const { data: projectsData } = useQuery<{ projects: ProjectItem[] }>({
    queryKey: ["projects"],
    queryFn: async () => {
      const r = await fetch("/api/projects");
      return r.json();
    },
  });

  // Fetch current project name for breadcrumb
  const { data: projectData } = useQuery<{ project: any }>({
    queryKey: ["project", selectedProjectId],
    queryFn: async () => {
      const r = await fetch(`/api/projects/${selectedProjectId}`);
      return r.json();
    },
    enabled: !!selectedProjectId,
  });

  const projects = projectsData?.projects || [];
  const currentProjectName = projectData?.project?.name;

  // Cmd+K shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setCmdOpen((prev) => !prev);
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Mark notification as read
  const markAsRead = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  }, []);

  // Mark all as read
  const markAllRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  // Command palette: run action
  const runCommand = useCallback(
    (command: () => void) => {
      setCmdOpen(false);
      command();
    },
    []
  );

  return (
    <header className="sticky top-0 z-40 border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60 shadow-sm">
      <div className="flex h-16 items-center gap-3 px-4">
        {/* Sidebar toggle */}
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleSidebar}
          className="shrink-0"
          aria-label="باز/بستن نوار کناری"
        >
          {sidebarCollapsed ? <ChevronLeft /> : <ChevronLeft className="rotate-180" />}
        </Button>

        {/* Logo and org name */}
        <div className="flex items-center gap-2.5">
          <div className="flex size-10 items-center justify-center rounded-lg bg-gradient-to-br from-amber-500 to-orange-700 text-primary-foreground shadow-md ring-1 ring-amber-400/20">
            <Building2 className="size-5" />
          </div>
          <div className="hidden sm:block">
            <div className="text-sm font-bold leading-tight">متره‌یار</div>
            <div className="text-[11px] text-muted-foreground leading-tight">
              پلتفرم متره و برآورد
            </div>
          </div>
        </div>

        {/* Dynamic Breadcrumb */}
        <Breadcrumb className="mr-4 hidden md:flex">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink
                className="cursor-pointer"
                onClick={() => setView("dashboard")}
              >
                {VIEW_LABELS.dashboard}
              </BreadcrumbLink>
            </BreadcrumbItem>

            {view !== "dashboard" && (
              <>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  {view === "project-detail" && selectedProjectId ? (
                    <BreadcrumbLink
                      className="cursor-pointer"
                      onClick={() => setView("projects")}
                    >
                      {VIEW_LABELS.projects}
                    </BreadcrumbLink>
                  ) : (
                    <BreadcrumbPage>{VIEW_LABELS[view]}</BreadcrumbPage>
                  )}
                </BreadcrumbItem>
              </>
            )}

            {view === "project-detail" && selectedProjectId && (
              <>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  {selectedProjectTab !== "overview" ? (
                    <BreadcrumbLink
                      className="cursor-pointer max-w-32 truncate"
                      onClick={() => selectProject(selectedProjectId, "overview")}
                    >
                      {currentProjectName || "پروژه"}
                    </BreadcrumbLink>
                  ) : (
                    <BreadcrumbPage className="max-w-32 truncate">
                      {currentProjectName || "پروژه"}
                    </BreadcrumbPage>
                  )}
                </BreadcrumbItem>
              </>
            )}

            {view === "project-detail" &&
              selectedProjectId &&
              selectedProjectTab !== "overview" && (
                <>
                  <BreadcrumbSeparator />
                  <BreadcrumbItem>
                    <BreadcrumbPage>
                      {TAB_LABELS[selectedProjectTab]}
                    </BreadcrumbPage>
                  </BreadcrumbItem>
                </>
              )}
          </BreadcrumbList>
        </Breadcrumb>

        {/* Right side actions */}
        <div className="mr-auto flex items-center gap-1.5">
          {/* Global Search Button */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCmdOpen(true)}
            className="hidden h-9 gap-2 text-muted-foreground sm:flex"
          >
            <Search className="size-4" />
            <span className="text-xs">جستجو...</span>
            <kbd className="pointer-events-none mr-1 inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground">
              ⌘K
            </kbd>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCmdOpen(true)}
            className="sm:hidden"
            aria-label="جستجو"
          >
            <Search className="size-4" />
          </Button>

          {/* Theme toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            aria-label="تغییر تم"
            className="relative"
          >
            <Sun className="size-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute size-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
          </Button>

          {/* Notification Dropdown */}
          <Popover open={notifOpen} onOpenChange={setNotifOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="relative"
                aria-label="اعلان‌ها"
              >
                <Bell className="size-4" />
                {unreadCount > 0 && (
                  <Badge
                    variant="destructive"
                    className="absolute -top-0.5 -left-0.5 flex size-4 items-center justify-center p-0 text-[9px]"
                  >
                    {toFa(unreadCount)}
                  </Badge>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent
              align="end"
              className="w-80 p-0"
            >
              <div className="flex items-center justify-between border-b px-4 py-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">اعلان‌ها</span>
                  {unreadCount > 0 && (
                    <Badge variant="secondary" className="text-[10px]">
                      {toFa(unreadCount)} خوانده‌نشده
                    </Badge>
                  )}
                </div>
                {unreadCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 text-xs text-amber-600 hover:text-amber-700"
                    onClick={markAllRead}
                  >
                    خواندن همه
                  </Button>
                )}
              </div>
              <ScrollArea className="max-h-80">
                <div className="divide-y">
                  {notifications.map((notif) => (
                    <button
                      key={notif.id}
                      onClick={() => {
                        markAsRead(notif.id);
                        if (notif.projectId) {
                          selectProject(notif.projectId);
                          setNotifOpen(false);
                        }
                      }}
                      className={cn(
                        "flex w-full items-start gap-3 px-4 py-3 text-right transition-colors hover:bg-muted/50",
                        !notif.read && "bg-amber-50/50 dark:bg-amber-950/20"
                      )}
                    >
                      <div
                        className={cn(
                          "mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full",
                          notif.type === "payment" &&
                            "bg-emerald-100 dark:bg-emerald-900/30",
                          notif.type === "boq" &&
                            "bg-amber-100 dark:bg-amber-900/30",
                          notif.type === "project" &&
                            "bg-orange-100 dark:bg-orange-900/30"
                        )}
                      >
                        <NotificationIcon type={notif.type} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span
                            className={cn(
                              "text-xs font-medium",
                              !notif.read && "text-foreground",
                              notif.read && "text-muted-foreground"
                            )}
                          >
                            {notif.title}
                          </span>
                          {!notif.read && (
                            <span className="size-1.5 shrink-0 rounded-full bg-amber-500" />
                          )}
                        </div>
                        <p className="mt-0.5 text-[11px] text-muted-foreground line-clamp-2">
                          {notif.description}
                        </p>
                        <span className="mt-1 text-[10px] text-muted-foreground/70">
                          {relativeTime(notif.timestamp)}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </ScrollArea>
              <div className="border-t px-4 py-2.5">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full text-xs text-amber-600 hover:text-amber-700"
                  onClick={() => setNotifOpen(false)}
                >
                  مشاهده همه اعلان‌ها
                </Button>
              </div>
            </PopoverContent>
          </Popover>

          {/* User menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="gap-2 px-2">
                <div className="relative">
                  <Avatar className="size-8 ring-2 ring-amber-200 dark:ring-amber-800">
                    <AvatarFallback className="bg-gradient-to-br from-amber-100 to-orange-100 text-amber-800 dark:from-amber-900 dark:to-orange-900 dark:text-amber-200">
                      {initials("آرش محمدی")}
                    </AvatarFallback>
                  </Avatar>
                  {/* Online status indicator */}
                  <span className="absolute -bottom-0.5 -left-0.5 flex size-3 items-center justify-center rounded-full bg-card">
                    <span className="size-2 rounded-full bg-emerald-500" />
                  </span>
                </div>
                <div className="hidden text-right sm:block">
                  <div className="text-xs font-semibold leading-tight">
                    آرش محمدی
                  </div>
                  <div className="text-[10px] text-muted-foreground leading-tight">
                    مدیر سازمان
                  </div>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>حساب کاربری</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Settings className="ml-2 size-4" />
                تنظیمات حساب
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Eye className="ml-2 size-4" />
                راهنما و پشتیبانی
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-destructive focus:text-destructive">
                خروج از حساب
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* ─── Command Palette Dialog ──────────────────────── */}
      <CommandDialog
        open={cmdOpen}
        onOpenChange={setCmdOpen}
        title="جستجوی سریع"
        description="جستجو در پروژه‌ها، بخش‌ها و دسترسی سریع"
      >
        <CommandInput placeholder="جستجو در پروژه‌ها و بخش‌ها..." />
        <CommandList>
          <CommandEmpty>نتیجه‌ای یافت نشد</CommandEmpty>

          {/* Quick Navigation */}
          <CommandGroup heading="دسترسی سریع">
            <CommandItem
              onSelect={() => runCommand(() => setView("dashboard"))}
            >
              <LayoutDashboard className="ml-2 size-4" />
              داشبورد
            </CommandItem>
            <CommandItem
              onSelect={() => runCommand(() => setView("projects"))}
            >
              <FolderTree className="ml-2 size-4" />
              لیست پروژه‌ها
            </CommandItem>
            <CommandItem
              onSelect={() => runCommand(() => setView("base-data"))}
            >
              <Database className="ml-2 size-4" />
              داده‌های پایه
            </CommandItem>
            <CommandItem
              onSelect={() => runCommand(() => setView("reports"))}
            >
              <FileBarChart className="ml-2 size-4" />
              گزارشات
            </CommandItem>
            <CommandItem
              onSelect={() => runCommand(() => setView("users"))}
            >
              <Users className="ml-2 size-4" />
              کاربران
            </CommandItem>
            <CommandItem
              onSelect={() => runCommand(() => setView("settings"))}
            >
              <Settings className="ml-2 size-4" />
              تنظیمات
            </CommandItem>
          </CommandGroup>

          <CommandSeparator />

          {/* Project Search */}
          <CommandGroup heading="پروژه‌ها">
            {projects.map((p) => (
              <CommandItem
                key={p.id}
                value={`${p.name} ${p.code}`}
                onSelect={() =>
                  runCommand(() => selectProject(p.id))
                }
              >
                <Building2 className="ml-2 size-4 text-amber-600" />
                <div className="flex flex-1 items-center gap-2">
                  <span>{p.name}</span>
                  <Badge variant="outline" className="text-[10px]">
                    {toFa(p.code)}
                  </Badge>
                  <span
                    className={cn(
                      "mr-auto size-2 rounded-full",
                      p.status === "ACTIVE"
                        ? "bg-emerald-500"
                        : "bg-amber-500"
                    )}
                  />
                </div>
              </CommandItem>
            ))}
          </CommandGroup>

          <CommandSeparator />

          {/* Recent Searches (static) */}
          <CommandGroup heading="جستجوهای اخیر">
            <CommandItem
              onSelect={() => runCommand(() => setView("dashboard"))}
            >
              <Search className="ml-2 size-4 text-muted-foreground" />
              داشبورد
            </CommandItem>
            <CommandItem
              onSelect={() => runCommand(() => setView("base-data"))}
            >
              <Search className="ml-2 size-4 text-muted-foreground" />
              داده‌های پایه — فهرست بها
            </CommandItem>
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </header>
  );
}
