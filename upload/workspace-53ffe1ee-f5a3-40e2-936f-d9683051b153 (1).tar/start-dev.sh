#!/bin/bash
cd /home/z/my-project
while true; do
  if ! ss -tlnp 2>/dev/null | grep -q ":3000 "; then
    pkill -9 -f "next-server" 2>/dev/null
    sleep 1
    NODE_OPTIONS="--max-old-space-size=3072" ./node_modules/.bin/next dev -p 3000 > /home/z/my-project/dev.log 2>&1 &
    echo "[$(date)] restarted" >> /home/z/my-project/watchdog.log
    sleep 10
  fi
  sleep 5
done
