#!/bin/bash
while true; do
  if ! ss -tlnp 2>/dev/null | grep -q ":3000 "; then
    pkill -9 -f "next-server" 2>/dev/null
    pkill -9 -f "next dev" 2>/dev/null
    sleep 1
    cd /home/z/my-project && NODE_OPTIONS="--max-old-space-size=3072" ./node_modules/.bin/next dev -p 3000 -H 0.0.0.0 > /home/z/my-project/dev.log 2>&1 &
    echo "[$(date)] restarted" >> /home/z/my-project/watchdog.log
    sleep 12
  fi
  sleep 5
done
