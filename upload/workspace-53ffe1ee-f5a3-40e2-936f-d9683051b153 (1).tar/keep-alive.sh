#!/bin/bash
# Keep-alive script that runs server and restarts if it dies
LOG=/home/z/my-project/dev.log
WATCHDOG_LOG=/home/z/my-project/watchdog.log

while true; do
  # Check if server is running
  if ! ss -tlnp 2>/dev/null | grep -q ":3000 "; then
    echo "[$(date)] Server not running, starting..." >> $WATCHDOG_LOG
    pkill -9 -f "next-server" 2>/dev/null
    pkill -9 -f "next dev" 2>/dev/null
    sleep 1
    
    # Start server
    cd /home/z/my-project
    NODE_OPTIONS="--max-old-space-size=3072" ./node_modules/.bin/next dev -p 3000 -H 0.0.0.0 > $LOG 2>&1 &
    SERVER_PID=$!
    echo "[$(date)] Started server PID: $SERVER_PID" >> $WATCHDOG_LOG
    
    # Wait for server to be ready
    for i in {1..15}; do
      sleep 2
      if curl -s -o /dev/null http://localhost:3000/ 2>/dev/null; then
        echo "[$(date)] Server ready after $((i*2))s" >> $WATCHDOG_LOG
        break
      fi
    done
  fi
  
  sleep 10
done
