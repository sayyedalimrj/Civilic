# Task 10 — full-stack-developer

## Task
Build Detail BOQ + Summary BOQ + Financial Sheet views under `src/components/views/project/`.

## Files Created
1. `src/components/views/project/detail-boq-view.tsx`
2. `src/components/views/project/financial-sheet-view.tsx`
3. `src/components/views/project/summary-boq-view.tsx`

## Work Log
- Read project context (store, fa utils, cascade engine, API routes, prisma schema, existing dashboard view, shadcn ui primitives).
- Detail BOQ: editable table with add dialog, price-list-item picker (search + 50 items), inline `QuantityCell` with 800ms debounce + Persian numeral parsing, edit/delete actions, cascade toasts (summaryBoqUpdated / financialSheetTotal / chaptersUpdated), loading skeleton, empty states, sticky header, max-h-[70vh] scroll.
- Financial Sheet: full table (کد/شرح/واحد/مقدار/قیمت واحد/مبلغ کل/فصل/مرجع/ستاره/ابزار), star toggle (starred → unit price editable chip), optimistic unit price mutation (`onMutate` cache patch + `onError` rollback), reference cycle button (NET/STATS/DAILY), chapter select (1-7 with titles), `AnalysisDialog` parsing `analysis` JSON + recharts mini bar chart + 4 colored factor cards, `DescendingPriceDialog` using `descendingPriceAdjustment` from cascade with adjustable threshold, sticky amber-gradient total footer (`faMoney` + `faRial`), starred-count badge.
- Summary BOQ: read-only table with کد/شرح/واحد/مقدار کل, sticky header, amber info banner (auto-computed from detail BOQ), "بازمحاسبه" button (invalidate `["project", id]` + refetch + toast), footer with unique code count + total quantity, empty-state CTA when detail rows exist but summary empty.
- All files: `'use client'`, RTL, Tailwind amber/orange/slate theme, `@/` aliases, relative fetch paths, `useAppStore` for `selectedProjectId`, TanStack Query key `["project", id]`, `faNum`/`faMoney`/`toFa`/`faRial` for Persian numerals, h-9 (36px) buttons/inputs, tabular-nums text-left numeric cells, custom scrollbar from globals.css.

## Stage Summary
- 3 production-ready view components delivered.
- `bun run lint` → EXIT=0 (clean).
- `npx tsc --noEmit` → 0 errors in the 3 new view files (pre-existing errors in unrelated files like `fa.ts`, `app-sidebar.tsx`, `dashboard-view.tsx`, and API routes were NOT modified per task constraints).
- No new routes, no API edits, no `page.tsx` / `layout.tsx` / `globals.css` changes.

## Cascade Sharing Note for Downstream Agents
All three views share the TanStack Query key `["project", selectedProjectId]` fetched from `/api/projects/[id]`. Mutations in any view call `qc.invalidateQueries({ queryKey: ["project", projectId] })`, so editing a detail BOQ row will refresh the financial sheet view and summary BOQ view if they're mounted (or next time they mount). Mutations return `cascade: { summaryBoqUpdated, financialSheetTotal, chaptersUpdated }` which the views surface in toasts.
