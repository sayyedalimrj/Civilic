// اسکریپت seed برای پلتفرم متره و برآورد
// شامل: tenant نمونه، کاربران، داده‌های پایه مرجع، پروژه نمونه
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  console.log("🚀 شروع seed...");

  // ── پاکسازی ──
  await db.paymentItem.deleteMany();
  await db.payment.deleteMany();
  await db.financialSheetItem.deleteMany();
  await db.chapter.deleteMany();
  await db.summaryBoq.deleteMany();
  await db.detailBoq.deleteMany();
  await db.project.deleteMany();
  await db.priceListItem.deleteMany();
  await db.priceList.deleteMany();
  await db.indexRecord.deleteMany();
  await db.coefficient.deleteMany();
  await db.cityDistance.deleteMany();
  await db.materialRate.deleteMany();
  await db.user.deleteMany();
  await db.tenant.deleteMany();

  // ── ۱. Tenant ──
  const tenant = await db.tenant.create({
    data: {
      id: "tenant-demo",
      name: "شرکت مهندسین مشاور عمران پارس",
      logoUrl: "/logo.svg",
      signatures: JSON.stringify([
        { role: "ناظر", name: "مهندس رضایی", signUrl: "" },
        { role: "مدیر", name: "دکتر احمدی", signUrl: "" },
        { role: "پیمانکار", name: "شرکت ساخت‌آفرین", signUrl: "" },
      ]),
    },
  });

  // ── ۲. کاربران ──
  await db.user.create({
    data: {
      id: "user-admin",
      tenantId: tenant.id,
      email: "admin@pars-eng.ir",
      name: "مهندس آرش محمدی",
      role: "ADMIN",
    },
  });
  await db.user.create({
    data: {
      id: "user-estimator",
      tenantId: tenant.id,
      email: "estimator@pars-eng.ir",
      name: "مهندس سارا کریمی",
      role: "ESTIMATOR",
    },
  });
  await db.user.create({
    data: {
      id: "user-biller",
      tenantId: tenant.id,
      email: "biller@pars-eng.ir",
      name: "مهندس علی موسوی",
      role: "BILLER",
    },
  });

  // ── ۳. فهرست‌های بها ──
  const priceListAbnieh = await db.priceList.create({
    data: {
      id: "pl-abnieh-1403",
      year: 1403,
      discipline: "ابنیه",
      title: "فهرست بهای ابنیه - سال ۱۴۰۳",
    },
  });
  const priceListAbnieh1404 = await db.priceList.create({
    data: {
      id: "pl-abnieh-1404",
      year: 1404,
      discipline: "ابنیه",
      title: "فهرست بهای ابنیه - سال ۱۴۰۴",
    },
  });
  await db.priceList.create({
    data: {
      id: "pl-rah-1403",
      year: 1403,
      discipline: "راه و باند",
      title: "فهرست بهی راه و باند - سال ۱۴۰۳",
    },
  });
  await db.priceList.create({
    data: {
      id: "pl-naft-1403",
      year: 1403,
      discipline: "نفت و گاز",
      title: "فهرست بهی نفت و گاز - سال ۱۴۰۳",
    },
  });

  // ── ۴. آیتم‌های فهرست بها (نمونه‌های واقعی) ──
  const priceItems = [
    { pl: priceListAbnieh1404.id, code: "010101", title: "خاکبرداری دستی در زمین معمولی تا عمق ۱.۵ متر", unit: "مترمکعب", price: 85000 },
    { pl: priceListAbnieh1404.id, code: "010102", title: "خاکبرداری با ماشین در زمین معمولی", unit: "مترمکعب", price: 65000 },
    { pl: priceListAbnieh1404.id, code: "010201", title: "خاکریزی و تراکم در لایه‌های ۳۰ سانتی", unit: "مترمکعب", price: 120000 },
    { pl: priceListAbnieh1404.id, code: "020101", title: "بتن‌ریزی M200 پی منفرد", unit: "مترمکعب", price: 2850000 },
    { pl: priceListAbnieh1404.id, code: "020102", title: "بتن‌ریزی M250 ستون", unit: "مترمکعب", price: 3200000 },
    { pl: priceListAbnieh1404.id, code: "020201", title: "آرماتوربندی میلگرد A3", unit: "کیلوگرم", price: 92000 },
    { pl: priceListAbnieh1404.id, code: "020301", title: "قالب‌بندی چوبی دیوار", unit: "مترمربع", price: 380000 },
    { pl: priceListAbnieh1404.id, code: "030101", title: "آجرچینی دیوار ۲۰ با ملات ماسه-سیمان", unit: "مترمربع", price: 920000 },
    { pl: priceListAbnieh1404.id, code: "030201", title: "دیوارچینی بلوک سیمانی ۱۵", unit: "مترمربع", price: 680000 },
    { pl: priceListAbnieh1404.id, code: "040101", title: "گچ‌کاری سفید دیوار", unit: "مترمربع", price: 185000 },
    { pl: priceListAbnieh1404.id, code: "050101", title: "عایق‌بندی قیرگونی پشت‌بام", unit: "مترمربع", price: 540000 },
    { pl: priceListAbnieh1404.id, code: "060101", title: "نصب درب فلزی ضدسرقت", unit: "عدد", price: 8500000 },
    { pl: priceListAbnieh1404.id, code: "060201", title: "نصب پنجره UPVC دوجداره", unit: "مترمربع", price: 4200000 },
    { pl: priceListAbnieh1404.id, code: "070101", title: "تأسیسات تأثيرگذار بر قیمت کلی", unit: "خواهش", price: 0 },
  ];
  for (const it of priceItems) {
    await db.priceListItem.create({
      data: {
        priceListId: it.pl,
        code: it.code,
        title: it.title,
        unit: it.unit,
        unitPrice: it.price,
      },
    });
  }

  // ── ۵. شاخص‌ها ──
  const indices = [
    { year: 1402, season: "بهار", discipline: "ابنیه", value: 1.0 },
    { year: 1402, season: "تابستان", discipline: "ابنیه", value: 1.08 },
    { year: 1402, season: "پاییز", discipline: "ابنیه", value: 1.15 },
    { year: 1402, season: "زمستان", discipline: "ابنیه", value: 1.22 },
    { year: 1403, season: "بهار", discipline: "ابنیه", value: 1.31 },
    { year: 1403, season: "تابستان", discipline: "ابنیه", value: 1.42 },
    { year: 1403, season: "پاییز", discipline: "ابنیه", value: 1.55 },
    { year: 1403, season: "زمستان", discipline: "ابنیه", value: 1.68 },
    { year: 1404, season: "بهار", discipline: "ابنیه", value: 1.78 },
    { year: 1404, season: "تابستان", discipline: "ابنیه", value: 1.89 },
    { year: 1402, season: "کلی", discipline: "کلی", value: 1.0 },
    { year: 1403, season: "کلی", discipline: "کلی", value: 1.45 },
    { year: 1404, season: "کلی", discipline: "کلی", value: 1.82 },
  ];
  for (const ix of indices) {
    await db.indexRecord.create({ data: ix });
  }

  // ── ۶. ضرایب منطقه‌ای و پایه ──
  const coefficients = [
    { year: 1404, discipline: "ابنیه", type: "REGIONAL", value: 1.12 },
    { year: 1404, discipline: "ابنیه", type: "BASE", value: 1.0 },
    { year: 1404, discipline: "ابنیه", type: "ALTITUDE", value: 1.05 },
    { year: 1404, discipline: "ابنیه", type: "FLOOR", value: 1.03 },
    { year: 1404, discipline: "راه و باند", type: "REGIONAL", value: 1.15 },
    { year: 1404, discipline: "راه و باند", type: "BASE", value: 1.0 },
  ];
  for (const c of coefficients) {
    await db.coefficient.create({ data: c });
  }

  // ── ۷. مسافت بین شهرها (نمونه) ──
  const cities = ["تهران", "اصفهان", "شیراز", "مشهد", "تبریز", "اهواز", "کرج", "قم", "رشت", "کرمان"];
  const distances: [string, string, number][] = [
    ["تهران", "اصفهان", 450],
    ["تهران", "شیراز", 920],
    ["تهران", "مشهد", 900],
    ["تهران", "تبریز", 600],
    ["تهران", "اهواز", 770],
    ["تهران", "کرج", 35],
    ["تهران", "قم", 145],
    ["تهران", "رشت", 320],
    ["تهران", "کرمان", 980],
    ["اصفهان", "شیراز", 480],
    ["اصفهان", "اهواز", 540],
    ["مشهد", "کرمان", 1100],
    ["تبریز", "رشت", 380],
    ["اهواز", "شیراز", 420],
    ["کرج", "قم", 165],
  ];
  for (const [from, to, km] of distances) {
    await db.cityDistance.create({ data: { fromCity: from, toCity: to, km } });
    await db.cityDistance.create({ data: { fromCity: to, toCity: from, km } });
  }

  // ── ۸. نرخ مصالح ──
  const materials = [
    { material: "فولاد (میله آرماتور A3)", source: "NET", year: 1404, rate: 92000, wasteFactor: 1.03 },
    { material: "فولاد (میله آرماتور A3)", source: "STATS", year: 1404, rate: 88000, wasteFactor: 1.03 },
    { material: "فولاد (میله آرماتور A3)", source: "DAILY", year: 1404, rate: 95000, wasteFactor: 1.03 },
    { material: "سیمان (کیسه ۵۰ کیلو)", source: "NET", year: 1404, rate: 92000, wasteFactor: 1.06 },
    { material: "سیمان (کیسه ۵۰ کیلو)", source: "STATS", year: 1404, rate: 89000, wasteFactor: 1.06 },
    { material: "سیمان (کیسه ۵۰ کیلو)", source: "DAILY", year: 1404, rate: 96000, wasteFactor: 1.06 },
    { material: "آجر مقیاسی", source: "NET", year: 1404, rate: 4500, wasteFactor: 1.05 },
    { material: "ماسه", source: "NET", year: 1404, rate: 320000, wasteFactor: 1.08 },
    { material: "شن", source: "NET", year: 1404, rate: 380000, wasteFactor: 1.08 },
    { material: "گچ", source: "NET", year: 1404, rate: 180000, wasteFactor: 1.04 },
  ];
  for (const m of materials) {
    await db.materialRate.create({ data: m });
  }

  // ── ۹. پروژه‌های نمونه ──
  const project1 = await db.project.create({
    data: {
      id: "proj-metro7",
      tenantId: tenant.id,
      name: "متروی تهران خط ۷ - ایستگاه شهرک",
      code: "TM7-S25",
      documentCode: "DOC-1403-0451",
      year: 1404,
      priceListId: priceListAbnieh1404.id,
      contractAmount: 2500000000, // ۲.۵ میلیارد ریال → نمایش ۲۵۰ میلیارد
      contractDate: new Date("2024-03-21"),
      status: "ACTIVE",
      location: "تهران",
      description: "ساخت ایستگاه مترو خط ۷ در منطقه شهرک غرب",
      coefficients: JSON.stringify({
        general: 1.0,
        regional: 1.12,
        altitude: 1.05,
        floors: 1.03,
        tunnelHardship: 1.18,
      }),
      cachedTotal: 2680000000,
      cachedExecuted: 1125000000,
      assignedUserIds: JSON.stringify(["user-estimator", "user-biller"]),
    },
  });

  const project2 = await db.project.create({
    data: {
      id: "proj-bridge",
      tenantId: tenant.id,
      name: "پل روگذار امام رضا (ع)",
      code: "PL-IM-12",
      documentCode: "DOC-1403-0388",
      year: 1404,
      priceListId: priceListAbnieh1404.id,
      contractAmount: 1850000000,
      contractDate: new Date("2024-05-15"),
      status: "ACTIVE",
      location: "تهران",
      description: "ساخت پل روگذار ۴ خطه",
      coefficients: JSON.stringify({
        general: 1.0,
        regional: 1.12,
        altitude: 1.0,
        floors: 1.0,
        tunnelHardship: 1.0,
      }),
      cachedTotal: 1920000000,
      cachedExecuted: 680000000,
      assignedUserIds: JSON.stringify(["user-estimator"]),
    },
  });

  const project3 = await db.project.create({
    data: {
      id: "proj-tunnel",
      tenantId: tenant.id,
      name: "تونل ۲ بزرگراه امام علی",
      code: "TN-IA-08",
      documentCode: "DOC-1403-0512",
      year: 1404,
      priceListId: priceListAbnieh1404.id,
      contractAmount: 4200000000,
      contractDate: new Date("2024-01-10"),
      status: "DRAFT",
      location: "تهران",
      description: "حفاری تونل دوم",
      coefficients: JSON.stringify({
        general: 1.0,
        regional: 1.12,
        altitude: 1.05,
        floors: 1.0,
        tunnelHardship: 1.25,
      }),
      cachedTotal: 0,
      cachedExecuted: 0,
      assignedUserIds: JSON.stringify(["user-estimator", "user-biller"]),
    },
  });

  // ── ۱۰. ریزمتره نمونه برای پروژه ۱ ──
  const detailBoqs = [
    { code: "010101", desc: "خاکبرداری دستی در زمین معمولی تا عمق ۱.۵ متر", unit: "مترمکعب", qty: 1250 },
    { code: "010102", desc: "خاکبرداری با ماشین در زمین معمولی", unit: "مترمکعب", qty: 3400 },
    { code: "010201", desc: "خاکریزی و تراکم", unit: "مترمکعب", qty: 850 },
    { code: "020101", desc: "بتن‌ریزی M200 پی منفرد", unit: "مترمکعب", qty: 420 },
    { code: "020102", desc: "بتن‌ریزی M250 ستون", unit: "مترمکعب", qty: 185 },
    { code: "020201", desc: "آرماتوربندی میلگرد A3", unit: "کیلوگرم", qty: 38500 },
    { code: "020301", desc: "قالب‌بندی چوبی دیوار", unit: "مترمربع", qty: 1200 },
    { code: "030101", desc: "آجرچینی دیوار ۲۰", unit: "مترمربع", qty: 950 },
    { code: "030201", desc: "دیوارچینی بلوک سیمانی ۱۵", unit: "مترمربع", qty: 1450 },
    { code: "040101", desc: "گچ‌کاری سفید دیوار", unit: "مترمربع", qty: 2100 },
    { code: "050101", desc: "عایق‌بندی قیرگونی پشت‌بام", unit: "مترمربع", qty: 480 },
    { code: "060101", desc: "نصب درب فلزی ضدسرقت", unit: "عدد", qty: 24 },
    { code: "060201", desc: "نصب پنجره UPVC دوجداره", unit: "مترمربع", qty: 320 },
  ];
  for (const d of detailBoqs) {
    const plItem = await db.priceListItem.findFirst({
      where: { priceListId: priceListAbnieh1404.id, code: d.code },
    });
    await db.detailBoq.create({
      data: {
        projectId: project1.id,
        priceListItemId: plItem?.id,
        code: d.code,
        description: d.desc,
        unit: d.unit,
        quantity: d.qty,
      },
    });
  }

  // ── ۱۱. خلاصه متره + برگه مالی (تجمیع) ──
  const summary = new Map<string, { code: string; desc: string; unit: string; total: number }>();
  for (const d of detailBoqs) {
    const key = d.code;
    if (summary.has(key)) {
      summary.get(key)!.total += d.qty;
    } else {
      summary.set(key, { code: d.code, desc: d.desc, unit: d.unit, total: d.qty });
    }
  }
  for (const [, s] of summary) {
    const plItem = await db.priceListItem.findFirst({
      where: { priceListId: priceListAbnieh1404.id, code: s.code },
    });
    const price = plItem?.unitPrice || 0;
    const total = s.total * price;
    const sb = await db.summaryBoq.create({
      data: {
        projectId: project1.id,
        priceListItemId: plItem?.id,
        code: s.code,
        description: s.desc,
        unit: s.unit,
        totalQuantity: s.total,
      },
    });
    await db.financialSheetItem.create({
      data: {
        projectId: project1.id,
        summaryBoqId: sb.id,
        code: s.code,
        description: s.desc,
        unit: s.unit,
        quantity: s.total,
        unitPrice: price,
        totalAmount: total,
        reference: "NET",
        chapterNo: parseInt(s.code.charAt(0)) || 1,
        isStarred: s.code === "070101",
        analysis: JSON.stringify({
          labor: total * 0.25,
          equipment: total * 0.15,
          material: total * 0.55,
          transport: total * 0.05,
        }),
      },
    });
  }

  // ── ۱۲. فصول ──
  const chapters = [
    { no: 1, title: "فصل اول — عملیات زمینی", amount: 412000000 },
    { no: 2, title: "فصل دوم — اسکلت و سازه", amount: 1280000000 },
    { no: 3, title: "فصل سوم — دیوارچینی و جداره", amount: 580000000 },
    { no: 4, title: "فصل چهارم — نازک‌کاری", amount: 388000000 },
    { no: 5, title: "فصل پنجم — تأسیسات", amount: 0, workshop: true, mode: "درصدی ۵٪" },
    { no: 6, title: "فصل ششم — در و پنجره", amount: 20000000 },
  ];
  for (const c of chapters) {
    await db.chapter.create({
      data: {
        projectId: project1.id,
        chapterNo: c.no,
        title: c.title,
        amount: c.amount,
        isWorkshopSetup: c.workshop || false,
        workshopMode: c.mode || null,
      },
    });
  }

  // ── ۱۳. صورت‌وضعیت دوره ۱ ──
  const payment1 = await db.payment.create({
    data: {
      projectId: project1.id,
      periodNo: 1,
      status: "APPROVED",
      executedAmount: 580000000,
      guarantee: 29000000,
      insurance: 11600000,
      tax: 29000000,
      netPayable: 510400000,
    },
  });
  const fsItems = await db.financialSheetItem.findMany({
    where: { projectId: project1.id },
    take: 8,
  });
  for (const fs of fsItems) {
    const execQty = fs.quantity * 0.45;
    const execAmt = execQty * fs.unitPrice;
    await db.paymentItem.create({
      data: {
        paymentId: payment1.id,
        financialSheetId: fs.id,
        code: fs.code,
        description: fs.description,
        unit: fs.unit,
        totalQuantity: fs.quantity,
        executedQuantity: execQty,
        executedPercent: 45,
        unitPrice: fs.unitPrice,
        executedAmount: execAmt,
        adjustedAmount: execAmt * 1.12,
        isAdjusted: true,
      },
    });
  }

  // صورت‌وضعیت دوره ۲ (در حال کار)
  const payment2 = await db.payment.create({
    data: {
      projectId: project1.id,
      periodNo: 2,
      status: "DRAFT",
      executedAmount: 545000000,
      guarantee: 27250000,
      insurance: 10900000,
      tax: 27250000,
      netPayable: 479350000,
    },
  });
  for (const fs of fsItems) {
    const execQty = fs.quantity * 0.85 - fs.quantity * 0.45;
    const execAmt = execQty * fs.unitPrice;
    await db.paymentItem.create({
      data: {
        paymentId: payment2.id,
        financialSheetId: fs.id,
        code: fs.code,
        description: fs.description,
        unit: fs.unit,
        totalQuantity: fs.quantity,
        executedQuantity: execQty,
        executedPercent: 85,
        unitPrice: fs.unitPrice,
        executedAmount: execAmt,
        adjustedAmount: execAmt * 1.18,
        isAdjusted: true,
      },
    });
  }

  // ریزمتره کوچک برای پروژه ۲
  for (const d of detailBoqs.slice(0, 6)) {
    const plItem = await db.priceListItem.findFirst({
      where: { priceListId: priceListAbnieh1404.id, code: d.code },
    });
    await db.detailBoq.create({
      data: {
        projectId: project2.id,
        priceListItemId: plItem?.id,
        code: d.code,
        description: d.desc,
        unit: d.unit,
        quantity: d.qty * 0.6,
      },
    });
  }

  console.log("✅ seed کامل شد.");
  console.log(`   - Tenant: ${tenant.name}`);
  console.log(`   - پروژه‌ها: ۳`);
  console.log(`   - فهرست بها: ۴ رشته`);
  console.log(`   - آیتم‌های فهرست: ${priceItems.length}`);
  console.log(`   - شاخص‌ها: ${indices.length}`);
  console.log(`   - مسافت‌ها: ${distances.length * 2}`);
  console.log(`   - نرخ مصالح: ${materials.length}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
